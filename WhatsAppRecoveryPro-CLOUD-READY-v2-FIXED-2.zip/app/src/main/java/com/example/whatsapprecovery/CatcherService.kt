package com.example.whatsapprecovery

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.Executors

class CatcherService : NotificationListenerService() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return

        val parsed = NotificationParser.parse(sbn.notification)
        if (parsed.conversation.isBlank() && parsed.text.isBlank()) return

        executor.execute {
            AppDatabase.get(applicationContext).insert(
                CapturedItem(
                    packageName = sbn.packageName,
                    conversation = parsed.conversation,
                    content = parsed.text,
                    kind = parsed.kind,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
