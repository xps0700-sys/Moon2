package com.example.whatsapprecovery

import android.app.Notification
import android.os.Bundle

data class ParsedNotification(
    val conversation: String,
    val text: String,
    val kind: String
)

object NotificationParser {
    fun parse(notification: Notification): ParsedNotification {
        val extras: Bundle = notification.extras
        val conversation = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()

        val lower = text.lowercase()
        val kind = when {
            lower.contains("image") || lower.contains("صورة") || lower.contains("photo") -> "صورة"
            lower.contains("video") || lower.contains("فيديو") -> "فيديو"
            lower.contains("audio") || lower.contains("صوت") || lower.contains("voice") -> "صوت"
            lower.contains("sticker") || lower.contains("ملصق") -> "ملصق"
            else -> "رسالة"
        }
        return ParsedNotification(conversation, text, kind)
    }
}
