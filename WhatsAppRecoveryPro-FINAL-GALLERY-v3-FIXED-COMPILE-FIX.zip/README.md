# WhatsApp Recovery Pro

Native Android/Kotlin project for Android 12, 13 and 14.

Developer: برمجة وتطوير محمد أمين

## What it does
- Uses Android's official NotificationListenerService API.
- Saves WhatsApp / WhatsApp Business notification text locally on the device.
- Works without an app network permission.
- Stores captured records in a local SQLite database.

## Important limitation
This app does not bypass WhatsApp security or directly read WhatsApp's private database. It can only save information that Android/WhatsApp exposes through notifications.

## Build
The project includes a cloud-friendly `gradlew` bootstrap for Gradle 8.7. The bootstrap downloads the official Gradle distribution when the build environment has internet access.
