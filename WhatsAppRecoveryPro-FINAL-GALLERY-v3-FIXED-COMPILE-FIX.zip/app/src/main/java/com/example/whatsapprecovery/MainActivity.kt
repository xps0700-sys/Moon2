package com.example.whatsapprecovery

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.Settings
import android.content.res.ColorStateList
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var countView: TextView
    private lateinit var mediaCountView: TextView
    private lateinit var emptyView: TextView
    private lateinit var serviceStatusView: TextView
    private lateinit var list: RecyclerView
    private lateinit var search: EditText
    private val db by lazy { AppDatabase.get(this) }
    private lateinit var adapter: CaptureAdapter
    private var allItems = emptyList<CapturedItem>()
    private var filter = "الكل"
    private val filters = listOf("الكل", "الرسائل", "الصور", "الملصقات", "الفيديو", "الصوت")
    private val fmt = SimpleDateFormat("yyyy/MM/dd • HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        countView = findViewById(R.id.countView)
        mediaCountView = findViewById(R.id.mediaCountView)
        emptyView = findViewById(R.id.emptyView)
        serviceStatusView = findViewById(R.id.serviceStatusView)
        list = findViewById(R.id.notificationsList)
        search = findViewById(R.id.searchView)
        adapter = CaptureAdapter { showDetails(it) }
        list.adapter = adapter
        list.setHasFixedSize(true)
        findViewById<View>(R.id.enableButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<View>(R.id.clearButton).setOnClickListener { clearAll() }
        search.addTextChangedListener(SimpleTextWatcher { render() })
        buildFilters()
        configureLayout()
    }

    override fun onResume() { super.onResume(); updateServiceStatus(); load() }

    private fun updateServiceStatus() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        serviceStatusView.text = if (enabled) "● الخدمة مفعلة — جاهز للحفظ" else "● الخدمة غير مفعلة — اضغط زر التفعيل"
    }

    private fun configureLayout() {
        list.layoutManager = LinearLayoutManager(this)
    }

    private fun load() {
        Thread {
            allItems = db.getAll()
            val mediaCount = allItems.count { !it.mediaPath.isNullOrBlank() && File(it.mediaPath!!).exists() }
            runOnUiThread {
                countView.text = allItems.size.toString()
                mediaCountView.text = mediaCount.toString()
                render()
            }
        }.start()
    }

    private fun buildFilters() {
        val bar = findViewById<LinearLayout>(R.id.filterBar)
        filters.forEach { name ->
            val b = Button(this).apply {
                text = name
                isAllCaps = false
                minHeight = 42
                minWidth = 0
                background = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, R.drawable.chip_bg)
                setTextColor(android.content.res.ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_selected), intArrayOf()),
                    intArrayOf(getColor(R.color.white), getColor(R.color.primaryText))
                ))
                setOnClickListener { filter = name; configureForFilter(); updateChipSelection(bar); render() }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 42).apply { marginEnd = 7 }
            bar.addView(b, lp)
        }
        updateChipSelection(bar)
    }

    private fun updateChipSelection(bar: LinearLayout) {
        for (i in 0 until bar.childCount) {
            val child = bar.getChildAt(i)
            child.isSelected = (child as? Button)?.text?.toString() == filter
        }
    }

    private fun configureForFilter() {
        val mediaGrid = filter == "الصور" || filter == "الملصقات" || filter == "الفيديو"
        list.layoutManager = if (mediaGrid) GridLayoutManager(this, 2) else LinearLayoutManager(this)
    }

    private fun hasMedia(item: CapturedItem): Boolean =
        !item.mediaPath.isNullOrBlank() && File(item.mediaPath!!).let { it.exists() && it.length() > 0 }

    private fun isMime(item: CapturedItem, prefix: String): Boolean =
        item.mediaMimeType?.lowercase(Locale.ROOT)?.startsWith(prefix) == true

    private fun render() {
        val q = search.text.toString().trim().lowercase(Locale.getDefault())
        val result = allItems.filter { item ->
            val matchesFilter = when (filter) {
                "الرسائل" -> item.kind == "رسالة" && !hasMedia(item)
                "الصور" -> hasMedia(item) && (isMime(item, "image/") || item.kind == "صورة")
                "الملصقات" -> hasMedia(item) && item.kind == "ملصق"
                "الفيديو" -> hasMedia(item) && (isMime(item, "video/") || item.kind == "فيديو")
                "الصوت" -> hasMedia(item) && (isMime(item, "audio/") || item.kind == "صوت")
                else -> true
            }
            matchesFilter && (q.isBlank() || item.conversation.lowercase(Locale.getDefault()).contains(q) || item.content.lowercase(Locale.getDefault()).contains(q))
        }
        adapter.submit(result)
        emptyView.visibility = if (result.isEmpty()) View.VISIBLE else View.GONE
        list.visibility = if (result.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showDetails(item: CapturedItem) {
        if (hasMedia(item)) {
            startActivity(Intent(this, MediaViewerActivity::class.java).apply {
                putExtra("path", item.mediaPath)
                putExtra("title", item.conversation.ifBlank { "WhatsApp" })
            })
            return
        }
        AlertDialog.Builder(this)
            .setTitle(item.conversation.ifBlank { "WhatsApp" })
            .setMessage("${item.content.ifBlank { "لا يوجد نص" }}\n\n${item.kind}\n${fmt.format(Date(item.timestamp))}")
            .setPositiveButton("إغلاق", null)
            .show()
    }

    private fun shareFile(path: String?, mime: String?) {
        if (path.isNullOrBlank()) return
        val file = File(path)
        if (!file.exists()) return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val type = mime?.takeIf { it.contains("/") } ?: "image/*"
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            this.type = type
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "مشاركة"))
    }

    private fun clearAll() {
        AlertDialog.Builder(this)
            .setTitle("مسح المحفوظات")
            .setMessage("سيتم حذف السجلات والوسائط المحفوظة من التطبيق.")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("مسح") { _, _ ->
                Thread {
                    allItems.mapNotNull { it.mediaPath }.forEach { runCatching { File(it).delete() } }
                    db.deleteAll()
                    runOnUiThread { load() }
                }.start()
            }.show()
    }
}

private class SimpleTextWatcher(val f: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) = f()
    override fun afterTextChanged(s: android.text.Editable?) {}
}
