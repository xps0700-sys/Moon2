package com.example.whatsapprecovery

data class CapturedItem(
    val id: Long = 0,
    val packageName: String,
    val conversation: String,
    val content: String,
    val kind: String,
    val timestamp: Long,
    val mediaPath: String? = null,
    val mediaMimeType: String? = null
)
