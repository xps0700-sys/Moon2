package com.example.whatsapprecovery

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AppDatabase private constructor(context: Context) : SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE captured_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            package_name TEXT NOT NULL,
            conversation TEXT NOT NULL,
            content TEXT NOT NULL,
            kind TEXT NOT NULL,
            timestamp INTEGER NOT NULL,
            media_path TEXT,
            media_mime_type TEXT
        )""".trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE captured_items ADD COLUMN media_path TEXT")
        if (oldVersion < 3) db.execSQL("ALTER TABLE captured_items ADD COLUMN media_mime_type TEXT")
    }

    fun insert(item: CapturedItem): Long {
        val values = ContentValues().apply {
            put("package_name", item.packageName)
            put("conversation", item.conversation)
            put("content", item.content)
            put("kind", item.kind)
            put("timestamp", item.timestamp)
            put("media_path", item.mediaPath)
            put("media_mime_type", item.mediaMimeType)
        }
        return writableDatabase.insert("captured_items", null, values)
    }

    fun getAll(): List<CapturedItem> {
        val items = mutableListOf<CapturedItem>()
        readableDatabase.query(
            "captured_items",
            arrayOf("id", "package_name", "conversation", "content", "kind", "timestamp", "media_path", "media_mime_type"),
            null, null, null, null, "timestamp DESC"
        ).use { c ->
            while (c.moveToNext()) items += CapturedItem(
                id = c.getLong(0),
                packageName = c.getString(1),
                conversation = c.getString(2),
                content = c.getString(3),
                kind = c.getString(4),
                timestamp = c.getLong(5),
                mediaPath = c.getString(6),
                mediaMimeType = c.getString(7)
            )
        }
        return items
    }

    fun deleteAll() = writableDatabase.delete("captured_items", null, null)

    companion object {
        private const val DB_NAME = "whatsapp_recovery.db"
        private const val DB_VERSION = 3
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: AppDatabase(context).also { INSTANCE = it }
        }
    }
}
