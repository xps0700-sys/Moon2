package com.example.whatsapprecovery

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // Android restores enabled notification-listener services according to system policy.
        // No background service is force-started here, avoiding Android 12–14 restrictions.
    }
}
