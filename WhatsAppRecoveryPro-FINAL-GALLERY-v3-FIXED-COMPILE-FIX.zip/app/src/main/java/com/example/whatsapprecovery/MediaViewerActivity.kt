package com.example.whatsapprecovery

import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MediaViewerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_media_viewer)
        val path = intent.getStringExtra("path")
        val title = intent.getStringExtra("title").orEmpty()
        val image = findViewById<ImageView>(R.id.fullImage)
        findViewById<TextView>(R.id.viewerTitle).text = title.ifBlank { "الوسائط المحفوظة" }
        findViewById<View>(R.id.closeViewer).setOnClickListener { finish() }
        val bmp = path?.let { File(it) }?.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }
        if (bmp != null) image.setImageBitmap(bmp) else image.setImageResource(R.drawable.media_placeholder)
    }
}
