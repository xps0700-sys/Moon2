package com.example.whatsapprecovery

import android.app.Notification
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle

/** Extracts media exposed by a notification. It never invents a media file. */
data class ParsedNotification(
    val conversation: String,
    val text: String,
    val kind: String,
    val bitmap: Bitmap? = null,
    val mediaUri: Uri? = null,
    val mediaMimeType: String? = null
)

object NotificationParser {
    fun parse(notification: Notification): ParsedNotification {
        val e = notification.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = e.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()

        var bestBitmap: Bitmap? = safeParcelable(e, Notification.EXTRA_PICTURE)
        if (bestBitmap == null) bestBitmap = safeParcelable(e, Notification.EXTRA_LARGE_ICON)
        var bestUri: Uri? = null
        var bestMime: String? = null
        var stickerHint = false

        fun considerUri(uri: Uri?, mime: String? = null, key: String = "") {
            if (uri == null || !isMediaUri(uri)) return
            val m = mime?.lowercase()?.takeIf { it.contains("/") }
            val keyLower = key.lowercase()
            val looksLikeMedia = m != null || keyLower.contains("media") || keyLower.contains("image") ||
                keyLower.contains("picture") || keyLower.contains("sticker") || keyLower.contains("uri")
            if (!looksLikeMedia) return
            if (bestUri == null) {
                bestUri = uri
                bestMime = m
            } else if (bestMime == null && m != null) {
                bestMime = m
            }
            if (keyLower.contains("sticker")) stickerHint = true
        }

        // Do not call the unavailable MessagingStyle extraction helper here.
        // That API is not part of the public Android SDK available to the current compileSdk and
        // causes the Kotlin compile to fail. The notification extras contain the same MessagingStyle
        // message bundles (EXTRA_MESSAGES), so the recursive inspector below handles them without
        // depending on a hidden/non-public extraction helper.

        // Inspect the raw extras. This catches Android/WhatsApp variants using nested bundles,
        // including MessagingStyle message dataUri/dataMimeType values.
        fun inspect(value: Any?, key: String = "") {
            when (value) {
                is Bitmap -> if (bestBitmap == null && value.width > 8 && value.height > 8) bestBitmap = value
                is Uri -> considerUri(value, null, key)
                is Bundle -> {
                    val mime = value.getString("android.dataMimeType") ?: value.getString("dataMimeType")
                    val uri = safeBundleUri(value, "android.dataUri") ?: safeBundleUri(value, "dataUri")
                    considerUri(uri, mime, key)
                    for (k in value.keySet()) {
                        val child = try { value.get(k) } catch (_: Throwable) { null }
                        inspect(child, k)
                    }
                }
                is Array<*> -> value.forEach { inspect(it, key) }
                is List<*> -> value.forEach { inspect(it, key) }
            }
        }
        for (k in e.keySet()) {
            val value = try { e.get(k) } catch (_: Throwable) { null }
            inspect(value, k)
        }

        val combined = listOf(text, bigText).filter { it.isNotBlank() }.distinct().joinToString("\n")
        val lower = combined.lowercase()
        val mime = bestMime?.lowercase()
        val kind = when {
            stickerHint || lower.contains("sticker") || lower.contains("ملصق") || lower.contains("ستيكر") -> "ملصق"
            mime?.startsWith("image/") == true || bestBitmap != null -> "صورة"
            mime?.startsWith("video/") == true -> "فيديو"
            mime?.startsWith("audio/") == true -> "صوت"
            lower.contains("image") || lower.contains("photo") || lower.contains("صورة") -> "صورة"
            lower.contains("video") || lower.contains("فيديو") -> "فيديو"
            lower.contains("audio") || lower.contains("voice") || lower.contains("صوت") -> "صوت"
            else -> "رسالة"
        }

        return ParsedNotification(title, combined, kind, bestBitmap, bestUri, mime)
    }

    private fun isMediaUri(uri: Uri): Boolean = uri.scheme == "content" || uri.scheme == "file" || uri.scheme == "android.resource"

    private fun safeBundleUri(bundle: Bundle, key: String): Uri? = try {
        if (Build.VERSION.SDK_INT >= 33) bundle.getParcelable(key, Uri::class.java) else @Suppress("DEPRECATION") (bundle.getParcelable(key) as? Uri)
    } catch (_: Throwable) { null }

    private inline fun <reified T> safeParcelable(bundle: Bundle, key: String): T? = try {
        if (Build.VERSION.SDK_INT >= 33) bundle.getParcelable(key, T::class.java) else @Suppress("DEPRECATION") (bundle.getParcelable(key) as? T)
    } catch (_: Throwable) { null }
}
