package com.example.whatsapprecovery

import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CaptureAdapter(private val onClick: (CapturedItem) -> Unit) : RecyclerView.Adapter<CaptureAdapter.VH>() {
    private val items = mutableListOf<CapturedItem>()
    private val fmt = SimpleDateFormat("yyyy/MM/dd • HH:mm", Locale.getDefault())
    fun submit(list: List<CapturedItem>) { items.clear(); items.addAll(list); notifyDataSetChanged() }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_capture, parent, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        private val img = v.findViewById<ImageView>(R.id.mediaThumb)
        private val conv = v.findViewById<TextView>(R.id.conversation)
        private val content = v.findViewById<TextView>(R.id.content)
        private val meta = v.findViewById<TextView>(R.id.meta)

        fun bind(item: CapturedItem) {
            conv.text = item.conversation.ifBlank { "WhatsApp" }
            content.text = item.content.ifBlank {
                if (!item.mediaPath.isNullOrBlank()) "وسائط محفوظة — اضغط للفتح" else "لا يوجد نص"
            }
            meta.text = "${item.kind}  •  ${fmt.format(Date(item.timestamp))}"
            img.setImageResource(R.drawable.media_placeholder)
            val path = item.mediaPath
            if (!path.isNullOrBlank()) {
                val file = File(path)
                if (file.exists() && file.length() > 0) {
                    val mime = item.mediaMimeType.orEmpty().lowercase(Locale.ROOT)
                    if (mime.startsWith("image/") || item.kind == "صورة" || item.kind == "ملصق") {
                        val bmp = BitmapFactory.decodeFile(path)
                        if (bmp != null) {
                            img.setImageBitmap(bmp)
                            img.scaleType = ImageView.ScaleType.CENTER_CROP
                        }
                    } else if (mime.startsWith("video/")) {
                        val bmp = try { ThumbnailUtils.createVideoThumbnail(path, MediaStore.Video.Thumbnails.MINI_KIND) } catch (_: Throwable) { null }
                        if (bmp != null) img.setImageBitmap(bmp)
                    }
                }
            }
            itemView.setOnClickListener { onClick(item) }
        }
    }
}
