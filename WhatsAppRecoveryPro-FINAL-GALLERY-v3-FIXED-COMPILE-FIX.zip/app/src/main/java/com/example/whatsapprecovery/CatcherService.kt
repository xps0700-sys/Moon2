package com.example.whatsapprecovery

import android.graphics.Bitmap
import android.net.Uri
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.Executors

class CatcherService : NotificationListenerService() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        val parsed = NotificationParser.parse(sbn.notification)
        if (parsed.conversation.isBlank() && parsed.text.isBlank() && parsed.bitmap == null && parsed.mediaUri == null) return

        executor.execute {
            val saved = saveMedia(parsed.bitmap, parsed.mediaUri, parsed.mediaMimeType, parsed.kind)
            val finalKind = if (saved != null && isImageMime(parsed.mediaMimeType)) {
                if (parsed.kind == "ملصق") "ملصق" else "صورة"
            } else parsed.kind
            AppDatabase.get(applicationContext).insert(
                CapturedItem(
                    packageName = sbn.packageName,
                    conversation = parsed.conversation,
                    content = parsed.text,
                    kind = finalKind,
                    timestamp = System.currentTimeMillis(),
                    mediaPath = saved,
                    mediaMimeType = parsed.mediaMimeType
                )
            )
        }
    }

    private fun saveMedia(bitmap: Bitmap?, uri: Uri?, mimeType: String?, kind: String): String? {
        return try {
            val dir = File(filesDir, "captured_media").apply { mkdirs() }
            val mime = mimeType?.lowercase(Locale.ROOT)
            val ext = extensionFor(mime, kind)
            val file = File(dir, "${System.currentTimeMillis()}_${(1000..9999).random()}.$ext")

            if (bitmap != null && bitmap.width > 8 && bitmap.height > 8) {
                FileOutputStream(file).use { out ->
                    val format = if (kind == "ملصق" || mime == "image/png" || mime == "image/webp") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                    bitmap.compress(format, 95, out)
                }
                return file.takeIf { it.exists() && it.length() > 0 }?.absolutePath
            }

            if (uri != null) {
                contentResolver.openInputStream(uri)?.use { input ->
                    file.outputStream().use { output -> input.copyTo(output) }
                }
                if (file.exists() && file.length() > 0) return file.absolutePath
                file.delete()
            }
            null
        } catch (_: Throwable) { null }
    }

    private fun extensionFor(mime: String?, kind: String): String = when {
        mime == "image/png" -> "png"
        mime == "image/webp" -> "webp"
        mime == "image/gif" -> "gif"
        mime == "image/jpeg" -> "jpg"
        mime == "video/mp4" -> "mp4"
        mime?.startsWith("video/") == true -> "mp4"
        mime == "audio/mpeg" -> "mp3"
        mime?.startsWith("audio/") == true -> "m4a"
        kind == "ملصق" -> "png"
        kind == "صورة" -> "jpg"
        else -> "bin"
    }

    private fun isImageMime(mime: String?): Boolean = mime?.lowercase(Locale.ROOT)?.startsWith("image/") == true

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
