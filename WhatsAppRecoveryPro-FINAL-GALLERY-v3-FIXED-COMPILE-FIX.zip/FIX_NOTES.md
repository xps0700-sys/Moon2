# Build fix

Fixed the Kotlin compilation error in `NotificationParser.kt`.

## Root cause
The previous code called `Notification.MessagingStyle.extractMessagingStyleFromNotification(notification)`, which is not available as a public SDK API for the project's compile configuration. This produced the GitHub Actions errors:

- `Unresolved reference: extractMessagingStyleFromNotification`
- `Cannot infer a type for this parameter`

## Fix
Removed that invalid API call. The parser already recursively scans `Notification.extras`, including the `EXTRA_MESSAGES` MessagingStyle bundles, and extracts `dataUri` / `dataMimeType` from those bundles. This keeps the media parsing behavior while making the source compile against the configured Android SDK.
